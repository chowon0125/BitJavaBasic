package project_0713;

public class Member {
	String id, pwd, name;
	int age, subPeriod, lessPeriod, familyNum, grade;
	Housing housing;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSubPeriod() {
		return subPeriod;
	}
	public void setSubPeriod(int subPeriod) {
		this.subPeriod = subPeriod;
	}
	public int getLessPeriod() {
		return lessPeriod;
	}
	public void setLessPeriod(int lessPeriod) {
		this.lessPeriod = lessPeriod;
	}
	public int getFamilyNum() {
		return familyNum;
	}
	public void setFamilyNum(int familyNum) {
		this.familyNum = familyNum;
	}
	public Housing getHousing() {
		return housing;
	}
	public void setHousing(Housing housing) {
		this.housing = housing;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	
	
	
}
