package dailyProject;

public class Strings {

}

class Notice extends Strings {
	String notice;
	String writer = "관리자";
	String date;
}

class Review extends Strings{
	String review;
	String writer = "Guest";
	String date;
}
