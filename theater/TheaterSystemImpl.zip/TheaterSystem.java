package theater;

import java.util.ArrayList;

public interface TheaterSystem {
	
	public ArrayList<Movie> getMovieList();
	public void setMovieList(ArrayList<Movie> movieList);
	public void signup(); //회원가입
	public void login();
	public void userPage(); //고객페이지
	public void movieSearch();
	public void reserveMovie(); //예매
	public void reservationCheck(); //예매확인
	public void chargeMoney(); //돈충전
	
	
	public void regProcess(String movie, String theater); //searchMovie + registerMovie
	public void searchMovie();
	public int searchMovie(String name); // 영화 이름을 받아서 movieList 내에서 검색, 해당 영화 인덱스를 인트값으로 돌려줌
	public void registerTheater(Theater theater); // Theater 객체를 받아 Theater(ArrayList)에 등록
	public void registerMovie(int k, String name); // movieList의 index값 k와 영화관 이름을 받아서 해당 영화관에 영화를 등록
	public void deleteMovie(String name); // 영화관 이름을 받아 해당 영화관에서 상영중인 영화 제거
	public void enterMovieInformation(Movie movie); // Movie를 받아 movieList에 등록 
	public void deleteMovieInformation(String name); // 영화 이름을 받아 movieList에서 해당 영화 제거, 상영중인 영화인 경우 Theater 객체의 변수 Movie(해당 영화)도 제거
	public void lookUpMovie(); // movieList 전체 목록 조회
	public void lookUpTheater(); // theater 전체 목록 조회
	/* 
	 * 
	 * 판매
	 * 
	 * 고객페이지-
	 * 고객 클래스 - 돈, 예매리스트, 아이디비번 등등, 
	 * (VIP고객클래스 - 고객 상속, 할인시스템 구현)
	 * 회원가입
	 * 로그인
	 * 돈을 충전 
	 * 예매 (할인) ㄱ 집어넣기
	 * 영화 예매 확인 customer의 예매리스트 arraylist{}  ...
	 * 영화검색 (장르별) - Movie.getGenre;
	 * 
	 * 
	 * 
	 * 
	 * (좌석선택)
	 * 
	 * 
	 * 영화 시스템 - 
	 * 영화 분류 (장르별)
	 * 영화 속성 - 장르, 가격, 기간, 이름, 배우들 , 상영관 ...
	 * 상영관에 영화 등록
	 * 상영관에 영화 삭제
	 * 
	 * 영화관 시스템
	 * 속성 - 상영관
	 * 
	 * 상영관 class
	 * 속성 - 좌석 (위치)
	 * 
	 * 
	 */

	
	
	
}


