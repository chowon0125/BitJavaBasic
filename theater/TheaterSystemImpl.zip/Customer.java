package theater;

import java.util.ArrayList;

public class Customer {
	
	String id,pw;
	ArrayList<Movie> Movies = new ArrayList<Movie>();
	int money;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public ArrayList<Movie> getMovies() {
		return Movies;
	}
	public void setMovies(ArrayList<Movie> movies) {
		Movies = movies;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	
	
	
	

}
