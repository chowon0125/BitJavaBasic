package theater;

public interface MovieSystem {
	
	

}
