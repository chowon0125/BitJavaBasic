package theater;

import java.util.*;

public class Movie {
	
	//Genre genre_;
	String title;
	String genre;
	String actor;
	String reservation;
	Calendar date;
	Theater theater;
	
	public Movie(String title, String genre, String actor, String reservation) {
		this.title = title;
		this.genre = genre;
		this.actor = actor;
		this.reservation = reservation;
		date = Calendar.getInstance();
		date.set(Integer.parseInt(reservation.split(" ")[0]), Integer.parseInt(reservation.split(" ")[1])-1, 
				Integer.parseInt(reservation.split(" ")[2]));
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public String getReservation() {
		return reservation;
	}

	public void setReservation(String reservation) {
		this.reservation = reservation;
	}

	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	public Theater getTheater() {
		return theater;
	}

	public void setTheater(Theater theater) {
		this.theater = theater;
	}

	
	public String toString() {
		if(theater!=null) {
			return "[제목 :" + title + " 장르 :" + genre + " 배우 :" + actor
					+ " 상영일 :" + date.get(Calendar.YEAR)+"/"+date.get(Calendar.MONTH)+"/"+date.get(Calendar.DATE) + " 상영관 :" + theater.name + "]";
		}
		else {
			return "[제목 :" + title + " 장르 :" + genre + " 배우 :" + actor
				+ " 상영일 :" + date.get(Calendar.YEAR)+"/"+date.get(Calendar.MONTH)+"/"+date.get(Calendar.DATE) + " 상영관 :미정]";
		}
	}
	
	
}

class Genre{
	
}
