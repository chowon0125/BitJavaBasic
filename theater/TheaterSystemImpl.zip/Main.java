package theater;

public class Main {
	public static void main(String[] args) {
		TheaterSystem ts = new TheaterSystemImpl();
		Customer cs = new Customer();
		
		Theater t1 = new Theater();
		Theater t2 = new Theater();
		Theater t3 = new Theater();
		Theater t4 = new Theater();
		Theater t5 = new Theater();
		
		t1.setName("A1");
		t2.setName("A2");
		t3.setName("A3");
		t4.setName("A4");
		t5.setName("A5");
		
		ts.registerTheater(t1);
		ts.registerTheater(t2);
		ts.registerTheater(t3);
		ts.registerTheater(t4);
		ts.registerTheater(t5);
		
		Movie m1 = new Movie("개무서움","공포","홍길동","2019 07 06");
		Movie m2 = new Movie("쿠콰가가쾅","액션","김길동","2019 07 04");
		Movie m3 = new Movie("사랑사랑히힣","멜로","이길동","2019 07 08");
		Movie m4 = new Movie("퍼퍼퍼퍼퍼어어펑","액션","박길동","2019 07 11");
		Movie m5 = new Movie("독립영화라 상영 안될듯","다큐","최길동","2020 07 06");
		
		ts.enterMovieInformation(m1);
		ts.enterMovieInformation(m2);
		ts.enterMovieInformation(m3);
		ts.enterMovieInformation(m4);
		ts.enterMovieInformation(m5);
		
		ts.regProcess("개무서움" , "A1");
		ts.regProcess("쿠콰가가쾅" , "A2");
		ts.regProcess("사랑사랑히힣" , "A3");
		ts.regProcess("퍼퍼퍼퍼퍼어어펑" , "A4");
		
		ts.lookUpTheater();
		
		ts.lookUpMovie();
		
		ts.deleteMovie("A3");
		
		ts.deleteMovieInformation("쿠콰가가쾅");
		
		ts.lookUpTheater();
		
		ts.lookUpMovie();
		
	}
}
