package theater;

import java.util.ArrayList;

public class TheaterSystemImpl implements TheaterSystem{
	
	ArrayList<Theater> theater = new ArrayList<Theater>();
	ArrayList<Movie> movieList = new ArrayList<Movie>();
	

	public ArrayList<Movie> getMovieList() {
		return movieList;
	}

	public void setMovieList(ArrayList<Movie> movieList) {
		this.movieList = movieList;
	}

	public void signup() {
		
	}

	public void login() {
		
	}

	public void userPage() {
		
	}

	public void movieSearch() {
		
	}
	
	public void searchMovie() {}

	public void reserveMovie() {
		
	}

	public void reservationCheck() {
		
	}

	public void chargeMoney() {
		
	}
	
	public void regProcess(String movie, String theater) {
		int k = searchMovie(movie);
		if(k==-1) {System.out.println("등록된 영화정보가 없습니다");}
		else {registerMovie(k, theater);}
	}
	
	public int searchMovie(String name) {
		int idx = 0, k = -1;
		for(Movie m : movieList) {
			if((m.getTitle()).equals(name)) {
				k = idx;
			}
			idx++;
		}
		return k;
	}
	
	public void registerTheater(Theater theater) {
		this.theater.add(theater);
	}

	public void registerMovie(int k, String name) {
		int idx = -1 ;
		for(int i=0; i<theater.size(); i++) {
			if(theater.get(i).getName().equals(name)) {
				idx = i;
				movieList.get(k).theater = theater.get(i);
				theater.get(i).movie = movieList.get(k);
			}
		}
		if(idx!=-1) {System.out.printf("%s 상영관에 '%s'영화를 등록했습니다.\n",theater.get(idx).getName(),theater.get(idx).movie.getTitle());}
		else {System.out.println("상영관 정보를 찾을 수 없습니다.");}
	}
	
	public void deleteMovie(String name) {
		int idx = -1 ;
		for(int i=0; i<theater.size(); i++) {
			if(theater.get(i).getName().equals(name)) {
				idx = i;
				theater.get(i).movie = null;
			}
		}
		if(idx!=-1) {System.out.printf("%s 상영관의 영화 정보를 제거했습니다.\n",theater.get(idx).getName());}
		else {System.out.println("상영관 정보를 찾을 수 없습니다.");}
	}
	
	public void enterMovieInformation(Movie movie) {
		movieList.add(movie);
	}
	
	public void deleteMovieInformation(String name) {
		int j = -1;
		int i = 0;
		for(Movie m : movieList) {
			if((m.getTitle()).contains(name)) {
				j = i; 
			}
			i++;
		}
		if(j!=-1) {
			System.out.printf("'%s' 영화를 목록에서 제거합니다.\n",movieList.get(j).getTitle());
			for(int k=0; k<theater.size();k++) {
				if(theater.get(k).movie!=null&&(theater.get(k).movie.getTitle()).contains(movieList.get(j).getTitle())) {
					theater.get(k).movie = null;
				}
			}
			movieList.remove(j);
		}
		else {System.out.println("영화 정보를 찾을 수 없습니다.");}
	}
	
	public void lookUpMovie() {
		for(Movie m : movieList) {
			System.out.println(m.toString()); 
		}
	}
	
	public void lookUpTheater() {
		for(Theater t : theater) {
			System.out.println(t.toString());
		}
	}


}
