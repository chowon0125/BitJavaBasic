package theater;

public class Theater {
	
	String name;
	int[][] seat;
	Movie movie;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[][] getSeat() {
		return seat;
	}
	public void setSeat(int[][] seat) {
		this.seat = seat;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	
	public String toString() {
		if(movie!=null) {
			return "[상영관 이름 :" + name + ", 상영 영화 :" + movie.getTitle() + "]";
		}
		else {
			return "[상영관 이름 :" + name + ", 상영 영화 : 미정]";
		}
	}
	
}
